/*
 * Created on 05/10/2006
 */
package japa.parser.ast.type;

import japa.parser.ast.Node;

/**
 * @author Julio Vilmar Gesser
 */
public abstract class Type extends Node {

    public Type(int line, int column) {
        super(line, column);
    }

}
