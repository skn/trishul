/*
 * Created on 05/10/2006
 */
package japa.parser.ast.expr;

/**
 * @author Julio Vilmar Gesser
 */
public abstract class LiteralExpr extends Expression {

    public LiteralExpr(int line, int column) {
        super(line, column);
    }
}
